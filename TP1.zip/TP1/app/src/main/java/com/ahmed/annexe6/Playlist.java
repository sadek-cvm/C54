package com.ahmed.annexe6;

public class Playlist {
    String nom, id;

    public Playlist(String nom, String id) {
        this.nom = nom;
        this.id = id;
    }
}
